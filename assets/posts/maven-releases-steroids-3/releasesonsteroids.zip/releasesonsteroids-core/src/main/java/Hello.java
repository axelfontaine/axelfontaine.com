public class Hello {

    public void test() {
        System.out.println("Hello");
    }
}
